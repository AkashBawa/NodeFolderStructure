"use strict";
const constants = {
  FILE_PATH: {
    USER: "/static/user",
  },
  DEFAULT_SKIP: 0,
  DEFAULT_LIMIT: 10,
};
module.exports = constants;
